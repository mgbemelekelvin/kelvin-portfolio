<?php $__env->startSection('meta'); ?>
    <meta name="description" content="The page you looking for is not in BetaTech Consults Limited." />
    <meta property="og:image" content="<?php echo e(asset('assets/img/logo/favicon.png')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title">404 Error</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">404 Error</li>
            </ul>
        </div>
    </div>

    <div class="error-area py-120">
        <div class="container">
            <div class="col-md-6 mx-auto">
                <div class="error-wrapper">
                    <img src="<?php echo e(asset('assets/img/error/01.png')); ?>" alt="">
                    <h2>Opos... Page Not Found!</h2>
                    <p>The page you looking for not found may be it not exist or removed.</p>
                    <a href="<?php echo e(route('home')); ?>" class="theme-btn">Go Back Home <i class="far fa-home"></i></a>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mgbem\Documents\PROJECTS\KELVIN_PORTFOLIO\resources\views/pages/404.blade.php ENDPATH**/ ?>