<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Welcome to my portfolio, where I showcase my passion for software engineering through a collection of impactful projects and demonstrate my expertise in crafting robust and innovative solutions." />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title">My Portfolio</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">My Portfolio</li>
            </ul>
        </div>
    </div>

    <div class="portfolio-area bg-2 py-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-7">
                    <div class="site-heading">
                        <span class="site-title-tagline"><i class="far fa-bring-forward"></i> Portfolio</span>
                        <h2 class="site-title">Explore My <span>Awesome</span> Work</h2>
                    </div>
                </div>
                <div class="filter-controls">
                    <ul class="filter-btns">
                        <li class="active" data-filter="*">All</li>
                        <li data-filter=".Ecommerce">Ecommerce</li>
                        <li data-filter=".FinTechs">FinTechs</li>
                        <li data-filter=".Applications_Portals">Applications / Portals</li>
                        <li data-filter=".Payments">Payments</li>
                        <li data-filter=".Websites">Websites</li>
                        <li data-filter=".Laravel">Laravel</li>
                        <li data-filter=".NodeJs">NodeJs</li>
                        <li data-filter=".Others">Others</li>
                    </ul>
                </div>
            </div>
            <div class="row filter-box">
                <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-4 filter-item <?php $__currentLoopData = explode(',', $portfolio->category); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($cat); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>">
                    <div class="portfolio-item">
                        <div class="portfolio-img">
                            <img src="<?php echo e(asset('assets/img/portfolio/'.$portfolio->image1)); ?>" alt="<?php echo e($portfolio->name); ?>-Kelvin-Mgbemele">
                        </div>
                        <div class="portfolio-content">
                            <a href="<?php echo e(route('portfolio',[$portfolio->meta_name])); ?>">
                                <h4 class="portfolio-title"><?php echo e(Str::limit($portfolio->name, 20, '...')); ?></h4>
                            </a>
                            <ul class="portfolio-category">
                                <li><a href="<?php echo e(route('portfolio',[$portfolio->meta_name])); ?>"><?php echo e(Str::limit($portfolio->technologies, 30, '...')); ?></a></li>
                            </ul>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/pages/portfolios.blade.php ENDPATH**/ ?>