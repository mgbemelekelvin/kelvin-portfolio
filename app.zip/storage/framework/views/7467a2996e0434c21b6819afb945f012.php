<!DOCTYPE html>
<html lang="en">
<head>
    <title>Kelvin .C. Mgbemele | <?php if(!empty($title)): ?> <?= $title; ?> <?php else: ?> Welcome to My Portfolio <?php endif; ?> </title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="title" content="Welcome to Kelvin .C. Mgbemele Portfolio">
    <meta name="author" content="Kelvin Chibuikem Mgbemele Portfolio">
    <meta name="keywords" content="Kelvin Chibuikem Mgbemele, Senior Software Engineer, Software Engineer, Software, Backend Programming, Programming, Php, Laravel, Nodejs, Database, MySql, Mongodb">
    <meta property="og:image" content="https://betatechng.com/assets/images/logo/logo-dark.png">
    <?php echo $__env->yieldContent('meta'); ?>
    <meta charset="utf-8">

    <link rel="icon" type="image/x-icon" href="<?php echo e(asset('assets/img/logo/favicon.png')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/all-fontawesome.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/animate.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/magnific-popup.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/owl.carousel.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <?php echo $__env->yieldContent('style'); ?>
</head>
<body class="home-3 bg">

<div class="preloader">
    <div class="loader-ripple">
        <div></div>
        <div></div>
    </div>
</div>

<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<main class="main">
<?php echo $__env->yieldContent('content'); ?>
</main>
<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<a href="#" id="scroll-top"><i class="far fa-arrow-up-to-line"></i></a>

<script src="<?php echo e(asset('assets/js/jquery-3.6.0.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/modernizr.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/imagesloaded.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.magnific-popup.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/counter-up.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/main.js')); ?>"></script>
<?php echo $__env->yieldContent('script'); ?>
</body>
</html>
<?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/layouts/app.blade.php ENDPATH**/ ?>