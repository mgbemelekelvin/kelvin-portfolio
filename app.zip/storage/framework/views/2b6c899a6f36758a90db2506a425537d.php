<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Welcome Kelvin Chibuikem Mgbemele. " />
    <meta property="og:image" content="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title">Portfolio</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">Portfolio</li>
            </ul>
        </div>
    </div>

    <div class="service-area bg py-120">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 text-right mb-3">
                    <button class="btn btn-primary" data-toggle="modal" data-target="#createPortfolio">Create Portfolio Item</button>
                </div>
                <div class="col-12 col-lg-12"><?php echo $__env->make('includes.notifications', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?></div>
                <div class="col-md-12 col-lg-12 text-center">
                    <div class="table-responsive">
                        <table class="table table-hover table-dark">
                            <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Name</th>
                                <th scope="col">Technologies</th>
                                <th scope="col">Created At</th>
                                <th scope="col">Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <th scope="row"><?php echo e($key+1); ?></th>
                                    <td><?php echo e($portfolio->name); ?></td>
                                    <td><?php echo e($portfolio->technologies); ?></td>
                                    <td><?php echo e($portfolio->created_at); ?></td>
                                    <td>
                                        <button class="btn btn-primary" data-toggle="modal" data-target="#viewPortfolio<?php echo e($portfolio->id); ?>">View</button>
                                        <button class="btn btn-success" data-toggle="modal" data-target="#editPortfolio<?php echo e($portfolio->id); ?>">Edit</button>
                                        <form class="main-form" action="<?php echo e(route('portfoliosMgtDelete',['portfolio_id'=>$portfolio->id])); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Start contact-us -->

    <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="viewPortfolio<?php echo e($portfolio->id); ?>" tabindex="-1" role="dialog" aria-labelledby="viewPortfolio<?php echo e($portfolio->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle" style="color: black;"><?php echo e($portfolio->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body showP" style="max-height: 500px; overflow: auto;">
                    <img src="<?php echo e(asset('assets/img/portfolio/'.$portfolio->image1)); ?>" style="height: 200px">
                    <p>Category: <?php echo e($portfolio->category); ?></p>
                    <p>Date: <?php echo e($portfolio->date); ?></p>
                    <p>Budget: <?php echo e($portfolio->budget); ?></p>
                    <p>Location: <?php echo e($portfolio->location); ?></p>
                    <p>Website: <?php echo e($portfolio->website); ?></p>
                    <p>Technologies: <?php echo e($portfolio->technologies); ?></p>
                    <p>Client: <?php echo e($portfolio->client); ?></p>
                    <?php echo $portfolio->description; ?>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </div>
    <div class="modal fade" id="editPortfolio<?php echo e($portfolio->id); ?>" tabindex="-1" role="dialog" aria-labelledby="editPortfolio<?php echo e($portfolio->id); ?>" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle" style="color: black;"><?php echo e($portfolio->name); ?></h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="main-form" action="<?php echo e(route('portfoliosMgtUpdate',['portfolio_id'=>$portfolio->id])); ?>" method="post" enctype="multipart/form-data" novalidate>
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PATCH'); ?>
                    <div class="modal-body" style="max-height: 500px; overflow: auto;">
                        <div class="row ">
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="name" style="color: black;">Name</label>
                                    <input class="form-control" id="name" name="name" type="text" required value="<?php echo e($portfolio->name); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="category" style="color: black;">Category</label>
                                    <input class="form-control" id="category" name="category" type="text" required value="<?php echo e($portfolio->category); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="date" style="color: black;">Date</label>
                                    <input class="form-control" id="date" name="date" type="date" value="<?php echo e($portfolio->date); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="budget" style="color: black;">Budget</label>
                                    <input class="form-control" id="budget" name="budget" type="text" value="<?php echo e($portfolio->budget); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="location" style="color: black;">Location</label>
                                    <input class="form-control" id="location" name="location" type="text" required value="<?php echo e($portfolio->location); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="website" style="color: black;">Website</label>
                                    <input class="form-control" id="website" name="website" type="text" value="<?php echo e($portfolio->website); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="technologies" style="color: black;">Technologies</label>
                                    <input class="form-control" id="technologies" name="technologies" type="text" required value="<?php echo e($portfolio->technologies); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="client" style="color: black;">Client</label>
                                    <input class="form-control" id="client" name="client" type="text" value="<?php echo e($portfolio->client); ?>"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="image1" style="color: black;">Image</label>
                                    <input class="form-control" id="image1" name="image1" type="file"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-12">
                                <div class="input-wrapper">
                                    <label class="input-label" for="description" style="color: black;">Description</label>
                                    <textarea class="form-control" id="description<?php echo e($portfolio->id); ?>" name="description" required style="color: black !important;"><?php echo $portfolio->description; ?></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Save changes</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="modal fade" id="createPortfolio" tabindex="-1" role="dialog" aria-labelledby="createPortfolio" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLongTitle" style="color: black;">Create Portfolio</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <form class="main-form" action="<?php echo e(route('portfoliosMgtCreate')); ?>" method="post" enctype="multipart/form-data" novalidate>
                    <?php echo csrf_field(); ?>
                    <div class="modal-body" style="max-height: 500px; overflow: auto;">
                        <div class="row ">
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="name" style="color: black;">Name</label>
                                    <input class="form-control" id="name" name="name" type="text" required/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="category" style="color: black;">Category</label>
                                    <input class="form-control" id="category" name="category" type="text" required/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="date" style="color: black;">Date</label>
                                    <input class="form-control" id="date" name="date" type="date"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="budget" style="color: black;">Budget</label>
                                    <input class="form-control" id="budget" name="budget" type="text"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="location" style="color: black;">Location</label>
                                    <input class="form-control" id="location" name="location" type="text" required/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="website" style="color: black;">Website</label>
                                    <input class="form-control" id="website" name="website" type="text"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="technologies" style="color: black;">Technologies</label>
                                    <input class="form-control" id="technologies" name="technologies" type="text" required/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="client" style="color: black;">Client</label>
                                    <input class="form-control" id="client" name="client" type="text"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-6">
                                <div class="input-wrapper">
                                    <label class="input-label" for="image1" style="color: black;">Image</label>
                                    <input class="form-control" id="image1" name="image1" type="file"/>
                                </div>
                            </div>
                            <div class="col-12 col-lg-12">
                                <div class="input-wrapper">
                                    <label class="input-label" for="description" style="`color: black;">Description</label>
                                    <textarea class="form-control" id="descriptionCreate" name="description" required style="color: black !important;"></textarea>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                        <button type="submit" class="btn btn-primary">Create</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/ckeditor-classic.bundle.js')); ?>"></script>
    <script>
        const KTCkeditor = function() {
            // Private functions
            <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            let demos<?php echo e($portfolio->id); ?> = function () {
                ClassicEditor
                    .create( document.querySelector( '#description<?php echo e($portfolio->id); ?>' ),{
                            mediaEmbed: {
                                previewsInData:true
                            },
                        }
                    )
                    .then( editor => {
                    } )
                    .catch( error => {
                        alert("Info !", error, "error");
                    } );
            }
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            let demosCreate = function () {
                ClassicEditor
                    .create( document.querySelector( '#descriptionCreate' ),{
                            mediaEmbed: {
                                previewsInData:true
                            },
                        }
                    )
                    .then( editor => {
                    } )
                    .catch( error => {
                        alert("Info !", error, "error");
                    } );
            }
            return {
                // public functions
                init: function() {
                    <?php $__currentLoopData = $portfolios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$portfolio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    demos<?php echo e($portfolio->id); ?>();
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    demosCreate();
                }
            };
        }();
        jQuery(document).ready(function() {
            KTCkeditor.init();
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/auth/portfolio.blade.php ENDPATH**/ ?>