<header class="header">
    <div class="main-navigation">
        <nav class="navbar navbar-expand-lg">
            <div class="container">
                <a class="navbar-brand" href="<?php echo e(route('home')); ?>">
                    <img src="<?php echo e(asset('assets/img/logo/logo.png')); ?>" alt="kelvin chibuikem Mgbemele" style="width: 250px;">
                </a>
                <div class="mobile-menu-right">
                    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#main_nav" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-btn-icon"><i class="far fa-bars"></i></span>
                    </button>
                </div>
                <div class="collapse navbar-collapse" id="main_nav">
                    <ul class="navbar-nav">
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'home'?'active':''); ?>" href="<?php echo e(route('home')); ?>" target="_blank">Home</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'services'?'active':''); ?>" href="<?php echo e(route('servicesMgt')); ?>">Services</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'portfolios'?'active':''); ?>" href="<?php echo e(route('portfoliosMgt')); ?>">Portfolio</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'testimonies'?'active':''); ?>" href="<?php echo e(route('testimonies')); ?>">Testimonies</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'feedback'?'active':''); ?>" href="<?php echo e(route('feedback')); ?>">Feedbacks</a></li>
                        <li class="nav-item"><a class="nav-link <?php echo e(!empty($nav) && $nav == 'changePassword'?'active':''); ?>" href="<?php echo e(route('changePassword')); ?>">Change Password</a></li>
                    </ul>
                    <div class="header-nav-right">
                        <div class="header-btn">
                            <a href="<?php echo e(route('logout')); ?>" class="theme-btn mt-2">Logout <i class="far fa-sign-out"></i></a>
                        </div>
                    </div>
                </div>
            </div>
        </nav>
    </div>
</header>
<?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/includes/header_admin.blade.php ENDPATH**/ ?>