<?php if(count($errors)): ?>
<div class="alert alert-custom alert-danger fade show" role="alert">
    <i class="fa fa-exclamation" aria-hidden="true"></i>
    <strong>Failed!</strong><br>
    <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li class="alert-text"><?php echo $error; ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
</div>
<?php endif; ?>

<?php if($message = Session::get('failed')): ?>
<div class="alert alert-danger alert-dismissible fade show" role="alert">
    <i class="fa fa-exclamation" aria-hidden="true"></i>
    <strong>Failed!</strong><br>
    <div class="alert-text">
        <?php if(is_array($message)): ?>
            <ul>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $msg; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <?php echo $message; ?>

        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible fade show" role="alert">
    <i class="icon-copy fa fa-check-circle" aria-hidden="true"></i>
    <strong>Success!</strong>
    <div class="alert-text">
        <?php if(is_array($message)): ?>
            <ul>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $msg; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <?php echo $message; ?>

        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-dismissible fade show" role="alert">
    <i class="icon-copy fa fa-warning" aria-hidden="true"></i>
    <strong>Warning!</strong>
    <div class="alert-text">
        <?php if(is_array($message)): ?>
            <ul>
            <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $msg; ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <?php echo $message; ?>

        <?php endif; ?>
    </div>
</div>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-dismissible fade show" role="alert">
    <i class="icon-copy fa fa-info-circle" aria-hidden="true"></i>
    <strong>Info</strong>
    <div class="alert-text">
        <?php if(is_array($message)): ?>
            <ul>
                <?php $__currentLoopData = $message; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $msg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><?php echo $msg; ?></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        <?php else: ?>
            <?php echo $message; ?>

        <?php endif; ?>
    </div>
</div>
<?php endif; ?>
<?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/includes/notifications.blade.php ENDPATH**/ ?>