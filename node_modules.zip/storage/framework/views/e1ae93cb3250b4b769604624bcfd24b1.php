<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Delivering tailored back-end solutions for seamless functionality, robust APIs, and efficient data management. Harnessing the power of Node.js, Laravel, and Python to create scalable applications that drive your business forward." />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title">My Services</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">My Services</li>
            </ul>
        </div>
    </div>

    <div class="service-area bg py-120">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <div class="site-heading">
                        <span class="site-title-tagline"><i class="far fa-bring-forward"></i> My Services</span>
                        <h2 class="site-title">Service Provide <span>For My</span> Clients / Organizations.</h2>
                    </div>
                </div>
            </div>
            <div class="row">
                <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-6 col-lg-3">
                    <div class="service-item">
                        <div class="service-icon">
                            <img src="<?php echo e(asset('assets/img/icon/'.$service->flaticon)); ?>" alt="">
                        </div>
                        <div class="service-content">
                            <h3 class="service-title">
                                <a href="javascript:;"><?php echo e($service->name); ?></a>
                            </h3>
                            <p> <?php echo e($service->short_detail); ?> </p>
                            <div class="service-arrow">
                                <a href="<?php echo e(route('service',[$service->meta_name])); ?>">Read More <i class="far fa-long-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/pages/services.blade.php ENDPATH**/ ?>