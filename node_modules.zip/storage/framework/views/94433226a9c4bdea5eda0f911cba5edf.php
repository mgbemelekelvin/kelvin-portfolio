<?php $__env->startSection('meta'); ?>
    <meta name="description" content="Welcome Kelvin Chibuikem Mgbemele. " />
    <meta property="og:image" content="<?php echo e(asset('assets/img/logo/logo.png')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('style'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="site-breadcrumb">
        <div class="container">
            <h2 class="breadcrumb-title">Welcome Kelvin</h2>
            <ul class="breadcrumb-menu">
                <li><a href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="active">My Dashboard</li>
            </ul>
        </div>
    </div>

    <div class="service-area bg py-120">
        <div class="container">
            <div class="row">
                <div class="col-md-12 col-lg-12 text-center">
                    <h1 style="color: white;">What would you like to odo today?</h1>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\PROJECTS\KELVIN_PORTFOLIO\resources\views/auth/dashboard.blade.php ENDPATH**/ ?>